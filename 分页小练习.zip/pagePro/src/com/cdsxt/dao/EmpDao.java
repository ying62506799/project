package com.cdsxt.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cdsxt.vo.Employee;

import pagingPro.DBUtil;

public class EmpDao {
	public  List<Employee> getAllData(int startRow,int pageRow){
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<Employee> list = new ArrayList<>();
		try {
			conn = DBUtil.getConn();
			ps = conn.prepareStatement("select * from db_employee limit ?,?");
			ps.setInt(1, startRow);
			ps.setInt(2, pageRow);
			rs = ps.executeQuery();
			while(rs.next()) {
				list.add(new Employee(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getInt(4)));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBUtil.close(rs,ps,conn);
		}
		return list;
	} 
	public  int getCount(){
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		int count = 0;
		try {
			conn = DBUtil.getConn();
			ps = conn.prepareStatement("select * from db_employee");
			rs = ps.executeQuery();
			rs.last();
			count= rs.getRow();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBUtil.close(rs,ps,conn);
		}
		return count;
	} 
}
