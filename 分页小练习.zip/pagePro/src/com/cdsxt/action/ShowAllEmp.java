package com.cdsxt.action;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cdsxt.dao.EmpDao;
import com.cdsxt.vo.Employee;

import pagingPro.PageUtil;

/**
 * Servlet implementation class ShowAllEmp
 */
@WebServlet("/showAllEmp")
public class ShowAllEmp extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	EmpDao empdao = new EmpDao();
	PageUtil pageUtil = null;
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int count = empdao.getCount();
		String mark = request.getParameter("mark");
		if ("query".equals(mark)) {
			String curPage = request.getParameter("curPage");
			pageUtil= new PageUtil(count, Integer.parseInt(curPage));
			List<Employee> allData = empdao.getAllData(pageUtil.getStartRow(), 10);
			request.setAttribute("emp", allData);
			request.setAttribute("pageinfo", pageUtil);
			request.getRequestDispatcher("showEmps.jsp").forward(request, response);
			return;
		} else {
			List<Employee> allData = empdao.getAllData(0, 10);
			pageUtil= new PageUtil(count, 1);
			request.setAttribute("emp", allData);
			request.setAttribute("pageinfo", pageUtil);
			request.getRequestDispatcher("showEmps.jsp").forward(request, response);
			return;
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
