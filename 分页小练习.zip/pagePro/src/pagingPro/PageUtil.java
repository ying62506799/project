package pagingPro;

public class PageUtil {
	private int count;//总条数 这个由数据库这边实现 找到多少条数据
	private int curPage;//当前页需要传入的数据 当前页码
	private int startRow;//起始行 
	private int	countNav; //总导航
	private int pageRow=10;//每页条数
	private int firstPage=1;//第一页 1
	private int lastPage;//最后一页
	private int prePage; //上一页
	private int nextPage;//下一页
	private int startNav; //起始导航
	private int endNav;//结束导航
	public static void main(String[] args) {
		PageUtil pageUtil = new PageUtil(80, 1);
		System.out.println("startRow"+pageUtil.getStartRow());
		System.out.println("countNav"+pageUtil.getCountNav());
		System.out.println("lastPage"+pageUtil.getLastPage());
		System.out.println("prePage"+pageUtil.getPrePage());
		System.out.println("nextPage"+pageUtil.getNextPage());
		System.out.println("startNav"+pageUtil.getStartNav());
		System.out.println("endNav"+pageUtil.getEndNav());
	}
	public PageUtil(int count,int curPage) {
		this.count=count;
		this.curPage=curPage;
		this.startRow = (this.curPage-1)*10;
		this.countNav =(int)Math.ceil(((double)count)/pageRow);//总导航
		this.lastPage= countNav;
		this.prePage=this.curPage==1?1:this.curPage-1;
		this.nextPage=this.curPage==countNav?countNav:this.curPage+1;
		if(countNav<=10) {
			this.startNav=1;
			this.endNav=lastPage;
		}else {
			if(this.curPage<=6) {
				this.startNav=1;
				this.endNav=10;
			}else if(this.curPage+4>=this.lastPage){
				this.startNav=this.lastPage-9;
				this.endNav=this.lastPage;
			}else {
				this.startNav=this.curPage-5;
				this.endNav=this.curPage+4;
			}
		}
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getCurPage() {
		return curPage;
	}
	public void setCurPage(int curPage) {
		this.curPage = curPage;
	}
	public int getStartRow() {
		return startRow;
	}
	public void setStartRow(int startRow) {
		this.startRow = startRow;
	}
	public int getCountNav() {
		return countNav;
	}
	public void setCountNav(int countNav) {
		this.countNav = countNav;
	}
	public int getPageRow() {
		return pageRow;
	}
	public void setPageRow(int pageRow) {
		this.pageRow = pageRow;
	}
	public int getFirstPage() {
		return firstPage;
	}
	public void setFirstPage(int firstPage) {
		this.firstPage = firstPage;
	}
	public int getLastPage() {
		return lastPage;
	}
	public void setLastPage(int lastPage) {
		this.lastPage = lastPage;
	}
	public int getPrePage() {
		return prePage;
	}
	public void setPrePage(int prePage) {
		this.prePage = prePage;
	}
	public int getNextPage() {
		return nextPage;
	}
	public void setNextPage(int nextPage) {
		this.nextPage = nextPage;
	}
	public int getStartNav() {
		return startNav;
	}
	public void setStartNav(int startNav) {
		this.startNav = startNav;
	}
	public int getEndNav() {
		return endNav;
	}
	public void setEndNav(int endNav) {
		this.endNav = endNav;
	}
	
	
}
