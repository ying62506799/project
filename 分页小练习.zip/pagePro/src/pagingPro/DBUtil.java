package pagingPro;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

public class DBUtil {
	
	private static String username;
	private static String password;
	private static String url;
	private static String driver;
	static {
		Properties ps = new Properties();
		try {
			ps.load(DBUtil.class.getResourceAsStream("/db.properties"));
			username = ps.getProperty("username");
			password = ps.getProperty("password");
			url = ps.getProperty("url");
			driver = ps.getProperty("driver");
			Class.forName(driver);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static Connection getConn() {
		Connection conn = null;
		try {
			conn = DriverManager.getConnection(url, username, password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}
	public static void close(Object...objects) {
		if(objects!=null&&objects.length>0) {
			for (Object object : objects) {
				if(object instanceof ResultSet) {
					try {
						((ResultSet) object).close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}else if(object instanceof PreparedStatement) {
					try {
						((PreparedStatement) object).close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}else if(object instanceof Connection) {
					try {
						((Connection) object).close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}
	}
}
